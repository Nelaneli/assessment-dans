const express = require('express')
const jobController = require('../Controllers/jobController')
const { getJob } = jobController
const userAuth = require('../Middlewares/userAuth')

const router = express.Router()

router.get('/', userAuth.verifyToken, getJob )

module.exports = router
const axios = require('axios');

const getJob = async (req, res) => {
    let joblist
    await axios({
        method: "get",
        url: "https://finalspaceapi.com/api/v0/character/?limit=2",
      }).then(function (response) {
        joblist = response.data
      });

      return res.status(201).send(joblist);
}

module.exports = {
    getJob,
}


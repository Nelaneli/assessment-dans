//importing modules
const express = require("express");
const db = require("../Models");
//Assigning db.users to User variable
const User = db.users;
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv').config()

//Function to check if username or email already exist in the database
//this is to avoid having two users with the same username and email
 const saveUser = async (req, res, next) => {
 //search the database to see if user exist
 try {
   const username = await User.findOne({
     where: {
       userName: req.body.userName,
     },
   });
   //if username exist in the database respond with a status of 409
   if (username) {
     return res.json(409).send("username already taken");
   }

   //checking if email already exist
   const emailcheck = await User.findOne({
     where: {
       email: req.body.email,
     },
   });

   //if email exist in the database respond with a status of 409
   if (emailcheck) {
     return res.json(409).send("Authentication failed");
   }

   next();
 } catch (error) {
   console.log(error);
 }
};

const verifyToken = async(req, res, next) => {
  let tokenHeader = req.headers['x-access-token'];

  if (!tokenHeader) {
    return res.status(403).send({
      auth: false,
      message: "Error",
      errors: "No token provided"
    });
  }

  if (tokenHeader?.split(' ')[0] !== 'Bearer') {
    return res.status(500).send({
      auth: false,
      message: "Error",
      errors: "Incorrect token format"
    });
  }

  let token = tokenHeader.split(' ')[1];

  if (!token) {
    return res.status(403).send({
      auth: false,
      message: "Error",
      errors: "No token provided"
    });
  }

  jwt.verify(token, process.env.secretKey, (err, decoded) => {
    if (err) {
      return res.status(500).send({
        auth: false,
        message: "Error",
        errors: err
      });
    }
    req.userId = decoded.id;
    next();
  });
}

//exporting module
 module.exports = {
 saveUser,
 verifyToken
};